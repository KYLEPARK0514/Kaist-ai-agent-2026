import json
import mimetypes
import os
from http.server import BaseHTTPRequestHandler, HTTPServer
from pathlib import Path
from urllib.parse import urlparse

from edupath_agent import run_agent


ROOT = Path(__file__).resolve().parents[1]
WEB_DIST = ROOT / "kaist-ai-webapp" / "build"


class EduPathHandler(BaseHTTPRequestHandler):
    def _send_json(self, payload: dict, status: int = 200) -> None:
        body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Access-Control-Allow-Origin", "*")
        self.end_headers()
        self.wfile.write(body)

    def _send_file(self, file_path: Path, content_type: str = "text/html; charset=utf-8") -> None:
        if not file_path.exists():
            self.send_error(404, "Not found")
            return
        body = file_path.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def do_OPTIONS(self) -> None:
        self.send_response(204)
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")
        self.end_headers()

    def do_GET(self) -> None:
        path = urlparse(self.path).path
        if path == "/api/health":
            self._send_json({"ok": True, "service": "EduPath AI Agent"})
            return

        if WEB_DIST.is_dir():
            if path.startswith("/assets/"):
                target = WEB_DIST / path.lstrip("/")
                if target.is_file():
                    mime, _ = mimetypes.guess_type(str(target))
                    self._send_file(target, mime or "application/octet-stream")
                    return
            if path in ("/", "/index.html"):
                idx = WEB_DIST / "index.html"
                if idx.is_file():
                    self._send_file(idx)
                    return

        self.send_error(404, "Not found")

    def do_POST(self) -> None:
        path = urlparse(self.path).path
        if path != "/api/agent/analyze":
            self.send_error(404, "Not found")
            return

        try:
            length = int(self.headers.get("Content-Length", "0"))
            raw = self.rfile.read(length).decode("utf-8")
            payload = json.loads(raw) if raw else {}
            profile = payload.get("profile", {})
            result = run_agent(profile)
            self._send_json(result)
        except Exception as exc:  # pylint: disable=broad-except
            self._send_json({"error": str(exc)}, status=400)


def main() -> None:
    host = "0.0.0.0"
    port = int(os.getenv("PORT", "8000"))
    server = HTTPServer((host, port), EduPathHandler)
    print(f"EduPath AI API at http://{host}:{port}")
    if (WEB_DIST / "index.html").is_file():
        print(f"SPA (production build): http://{host}:{port}/")
    else:
        print("SPA not built. Run: cd kaist-ai-webapp && npm install && npm run build")
        print("Dev UI with hot reload: cd kaist-ai-webapp && npm run dev  (proxies /api to this server)")
    server.serve_forever()


if __name__ == "__main__":
    main()
